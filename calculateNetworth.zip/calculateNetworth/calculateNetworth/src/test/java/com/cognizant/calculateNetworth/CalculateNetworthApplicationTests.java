package com.cognizant.calculateNetworth;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cognizant.calculateNetworth.controller.StocksContoller;

@AutoConfigureMockMvc
@SpringBootTest
class CalculateNetworthApplicationTests {
	@Autowired
	private StocksContoller controller;
	@Autowired
	MockMvc mockMvc;

	@Autowired
	private MockMvc mvc;

	@Test
	void contextLoads() {
		assertNotNull(controller);
	}

	@Test
	public void testGetAsset() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/NetWorth/calculateNetworth/101")
				.accept(MediaType.APPLICATION_JSON).header("Authorization", "token");
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		// String expectedJson=this.mapToJson(mutualFund);
		String outputJson = result.getResponse().getContentAsString();
		assertThat(outputJson).isEqualTo(outputJson);

	}

	@Test
	public void testGetAllMutualFunds() throws Exception {
		/*RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/NetWorth/mutualfunds")
				.accept(MediaType.APPLICATION_JSON).header("Authorization", "token");
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String outputJson = result.getResponse().getContentAsString();
		assertThat(outputJson).isEqualTo(outputJson);*/

	}

	@Test
	public void testGetStcokName() throws Exception {

		/*RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/NetWorth//pershare/Amazon")
				.accept(MediaType.APPLICATION_JSON).header("Authorization", "token");
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String outputJson = result.getResponse().getContentAsString();
		assertThat(outputJson).isEqualTo(outputJson);*/

	}

	@Test
	public void testGetAllStocks() throws Exception {
		
		/*RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/NetWorth/shares")
				.accept(MediaType.APPLICATION_JSON).header("Authorization", "token");
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String outputJson = result.getResponse().getContentAsString();
		assertThat(outputJson).isEqualTo(outputJson);*/

	}
}
