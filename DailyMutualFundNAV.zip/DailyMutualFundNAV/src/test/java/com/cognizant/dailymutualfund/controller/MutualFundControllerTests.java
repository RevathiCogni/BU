package com.cognizant.dailymutualfund.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cognizant.dailymutualfund.model.MutualFund;
import com.cognizant.dailymutualfund.service.MutualFundServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author Ruksar, Revathi, Rameswara, Prachi
 *
 */
//@RunWith(SpringRunner.class)
@WebMvcTest(controllers = MutualFundController.class)
class MutualFundControllerTests {

	@Autowired
	MockMvc mockMvc;

	@MockBean
	MutualFundServiceImpl serviceImpl;

	/**
	 * testing method that returns all mutual fund details
	 * 
	 * @throws Exception
	 */
	@Test
	public void testgetAllDailyMutualFund() throws Exception {
		MutualFund mutualFund1 = new MutualFund("AXIS", "Axis Bluechip fund", 9800.0);
		MutualFund mutualFund2 = new MutualFund("DSP", "DSP Midcap Fund", 6000.0);
		MutualFund mutualFund3 = new MutualFund("SBI", "SBI Small Cap Fund", 4300.0);
		List<MutualFund> shareDetailsList = new ArrayList<>();
		shareDetailsList.add(mutualFund1);
		shareDetailsList.add(mutualFund2);
		shareDetailsList.add(mutualFund3);

		Mockito.when(serviceImpl.getAllMutualFund()).thenReturn(shareDetailsList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/dailyAllMutualFundNav")
				.accept(MediaType.APPLICATION_JSON).header("Authorization", "token");
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String outputJson = result.getResponse().getContentAsString();
		assertThat(outputJson).isEqualTo(outputJson);

	}

	/**
	 * testing method that returns share by passing mutual fund name
	 * 
	 * @throws Exception
	 */
	@Test
	public void testgetMutualfundByName() throws Exception {
		MutualFund mutualFund = new MutualFund("AXIS", "Axis Bluechip fund", 9800.0);
		Mockito.when(serviceImpl.getMutualFundByName(Mockito.anyString())).thenReturn(mutualFund);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/dailyMutualFundNav/name/Axis Bluechip fund")
				.accept(MediaType.APPLICATION_JSON).header("Authorization", "token");
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String outputJson = result.getResponse().getContentAsString();
		assertThat(outputJson).isEqualTo(outputJson);
	}

	/**
	 * This method is for a negative testcase for getMutualFundByName method
	 * 
	 * @throws Exception
	 */

	@Test
	public void testgetMutualfundByNameNegative() throws Exception {
		MutualFund mutualFund = new MutualFund("HYD", "Hydra fund", 9800.0);
		when(serviceImpl.getMutualFundByName("Hydra Fund")).thenReturn(mutualFund);
		mockMvc.perform(
				MockMvcRequestBuilders.get("/dailyMutualFundNav/name/Hydra fund").content(this.mapToJson(mutualFund))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest());

	}

	/**
	 * testing method that returns share by passing mutual fund id
	 * 
	 * @throws Exception
	 */
	@Test
	public void testgetMutualFundById() throws Exception {
		MutualFund mutualFund = new MutualFund("AXIS", "Axis Bluechip fund", 9800.0);
		when(serviceImpl.getMutualFundById("AXIS")).thenReturn(mutualFund);
		mockMvc.perform(MockMvcRequestBuilders.get("/dailyMutualFundNav/AXIS").content(this.mapToJson(mutualFund))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.header("Authorization", "token")).andExpect(status().isOk());
	}
	
	/**
	 * This method is for a negative testcase for getMutualFundById method
	 * 
	 * @throws Exception
	 */

	@Test
	public void testgetMutualfundByIdNegative() throws Exception {
		MutualFund mutualFund = new MutualFund("HYD", "Hydra fund", 9800.0);
		when(serviceImpl.getMutualFundByName("HYD")).thenReturn(mutualFund);
		mockMvc.perform(
				MockMvcRequestBuilders.get("/dailyMutualFundNav/HYD").content(this.mapToJson(mutualFund))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest());

	}

	private String mapToJson(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(object);

	}

}