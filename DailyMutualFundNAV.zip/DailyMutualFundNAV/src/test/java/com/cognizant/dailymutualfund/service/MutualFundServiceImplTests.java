package com.cognizant.dailymutualfund.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cognizant.dailymutualfund.controller.AuthClient;
import com.cognizant.dailymutualfund.exception.MutualFundNotFoundException;
import com.cognizant.dailymutualfund.model.AuthResponse;
import com.cognizant.dailymutualfund.model.MutualFund;
import com.cognizant.dailymutualfund.repository.MutualFundRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
class MutualFundServiceImplTests {

	@Autowired
	private MutualFundServiceImpl serviceImpl;
	@MockBean
	AuthClient authClient;
	@MockBean
	private MutualFundRepository repository;

	/**
	 * This method is used to test the serviceImpl getMutualFundbyName method
	 */
	@Test
	public void testgetMutualFundbyName() {

		MutualFund mutualFund = new MutualFund("Axis", "Axis Bluechip fund", 9800.0);
		Mockito.when(repository.findByMutualFundName("Axis Bluechip fund")).thenReturn(mutualFund);
		assertThat(serviceImpl.getMutualFundByName("Axis Bluechip fund")).isEqualTo(mutualFund);

	}

	/**
	 *  This method is used to negatively test the serviceImpl getMutualFundbyName method
	 */
	@Test
	public void testgetMutualFundbyNameNegative() {
		MutualFund mutualFund = new MutualFund("Axis", "A Bluechip fund", 9800.0);
		Mockito.when(repository.findByMutualFundName("A Bluechip fund")).thenReturn(mutualFund);
		assertThat(serviceImpl.getMutualFundByName("Axis Bluechip fund")).isNotEqualTo(mutualFund);
	}

	/**
	 * This method is used to test the serviceImpl getMutualFundbyId method
	 */
	@Test
	public void testgetMutualFundbyId() {

		MutualFund mutualFund = new MutualFund("Axis", "Axis Bluechip fund", 9800.0);
		Mockito.when(repository.findByMutualFundId("AXIS")).thenReturn(mutualFund);
		assertThat(serviceImpl.getMutualFundById("AXIS")).isEqualTo(mutualFund);

	}

	/**
	 * This method is used to test the serviceImpl getAllMutualFund method
	 */
	@Test
	public void testgetAllMutalFund() {
		MutualFund mutualFund1 = new MutualFund("AXIS", "Axis Bluechip fund", 9800.0);
		MutualFund mutualFund2 = new MutualFund("DSP", "DSP Midcap Fund", 6000.0);
		MutualFund mutualFund3 = new MutualFund("SBI", "SBI Small Cap Fund", 4300.0);
		List<MutualFund> mutualFundList = new ArrayList<>();
		mutualFundList.add(mutualFund1);
		mutualFundList.add(mutualFund2);
		mutualFundList.add(mutualFund3);
		Mockito.when(repository.findAll()).thenReturn(mutualFundList);
		assertThat(serviceImpl.getAllMutualFund()).isEqualTo(mutualFundList);
	}

	@Test
	void isSessionValid() {
		when(authClient.getValidity("token")).thenReturn(new AuthResponse("101", "pwd", true));
		assertEquals(true, serviceImpl.isSessionValid("token"));
	}

}
