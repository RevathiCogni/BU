insert into mutual_fund values ('AXIS','Axis Bluechip fund',9800.0);
insert into mutual_fund values ('DSP','DSP Midcap Fund',6000.0);
insert into mutual_fund values ('SBI','SBI Small Cap Fund',4300.0);